Saves recovered by C-Drive on March 2, 2025 via the Wayback Machine archive at:

https://web.archive.org/web/20070918222423/http://fpwd2k.gswf.org/EditPacksUpdated.html
